from ...Classification.Custom import ClassificationModelTrainer, CustomImageClassification





class ModelTraining(ClassificationModelTrainer):
    """
    Deprecated! 
    Replaced with 'imageai.Classification.Custom.ClassificationModelTrainer'
    """
    def __call__(self):
        None

class CustomImagePrediction(CustomImageClassification):
    """
    Deprecated! 
    Replaced with 'imageai.Classification.Custom.CustomImageClassification'
    """

    def __call__(self):
        None